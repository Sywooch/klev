﻿/*
 Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("codesnippet","ca",{button:"Insereix el fragment de codi",codeContents:"Contingut del codi",emptySnippetError:"El fragment de codi no pot estar buit.",language:"Idioma",title:"Fragment de codi",pathName:"fragment de codi"});